package util;

/**
 * Created by Peng on 4/6/15.
 */
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseConnector {

    // database name
    private static final String DATABASE_NAME = "StudentRecords";
    private SQLiteDatabase database; // database object
    private DatabaseOpenHelper databaseOpenHelper; // database helper

    // public constructor for DatabaseConnector
    public DatabaseConnector(Context context) {
        // create a new DatabaseOpenHelper
        databaseOpenHelper = new DatabaseOpenHelper(context, DATABASE_NAME,
                null, 1);
    } // end DatabaseConnector constructor

    // open the database connection
    public void open() throws SQLException {
        // create or open a database for reading/writing
        database = databaseOpenHelper.getWritableDatabase();
    } // end method open

    // close the database connection
    public void close() {
        if (database != null)
            database.close(); // close the database connection
    } // end method close

    // inserts a new record of student score in the database
    public void insertRecord(int Id, int q1, int q2, int q3, int q4, int q5) {
        ContentValues record = new ContentValues();
        record.put("Id", Id);
        record.put("q1", q1);
        record.put("q2", q2);
        record.put("q3", q3);
        record.put("q4", q4);
        record.put("q5", q5);

        open(); // open the database
        database.insert("records", null, record);
        close(); // close the database
    } // end method insertContact

    // inserts a new record in the database
    public void updateContact(int studId, int q1, int q2, int q3, int q4, int q5) {
        ContentValues record = new ContentValues();
        // editRecord.put("studId", studId);
        record.put("q1", q1);
        record.put("q2", q2);
        record.put("q3", q3);
        record.put("q4", q4);
        record.put("q5", q5);

        open(); // open the database
        database.update("records", record, "Id=" + studId, null);
        close(); // close the database
    } // end method updateRecords

    // return a Cursor with all records information in the database
    public Cursor getAllRecords() {
        open();
        return database.query("records", new String[] { "Id", "q1", "q2",
                "q3", "q4", "q5" }, null, null, null, null, null, null);
    } // end method getAllRecords

    // get a Cursor containing all information about the contact specified
    // by the given id
    public Cursor getOneRecord(long id) {
        return database.query("records", null, "Id=" + id, null, null,
                null, null, null);
    } // end method getOnContact

    // delete the contact specified by the given String name
    public void deleteRecord(long id) {
        open(); // open the database
        database.delete("records", "Id=" + id, null);
        close(); // close the database
    } // end method deleteContact

    public int getHighScore(int i) {
        open(); // open the database

        Cursor cursor = database.query("records", new String[] { "max(q" + i + ")" },
                null, null, null, null, null);
        try {
            cursor.moveToFirst();
            return cursor.getInt(0);
        } finally {
            cursor.close();
        }
    }

    public int getLowScore(int i) {
        open(); // open the database

        Cursor cursor = database.query("records", new String[] { "min(q" + i + ")" },
                null, null, null, null, null);
        try {
            cursor.moveToFirst();
            return cursor.getInt(0);
        } finally {
            cursor.close();
        }
    }

    public int getAvgScore(int i) {
        open(); // open the database
        Cursor cursor = database.query("records", new String[] { "avg(q" + i + ")" },
                null, null, null, null, null);
        try {
            cursor.moveToFirst();
            return cursor.getInt(0);
        } finally {
            cursor.close();
        }
    }

    private class DatabaseOpenHelper extends SQLiteOpenHelper {
        // public constructor
        public DatabaseOpenHelper(Context context, String name,
                                  CursorFactory factory, int version) {
            super(context, name, factory, version);
        } // end DatabaseOpenHelper constructor

        // creates the records table when the database is created
        @Override
        public void onCreate(SQLiteDatabase db) {
            // query to create a new table named contacts
            String createQuery = "CREATE TABLE records"
                    + "(id integer primary key autoincrement,"
                    + "studId INT,"
                    + "q1 INT, q2 INT, q3 INT,"
                    + "q4 INT, q5 INT);";

            db.execSQL(createQuery); // execute the query
        } // end method onCreate

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        } // end method onUpgrade
    } // end class DatabaseOpenHelper
}

