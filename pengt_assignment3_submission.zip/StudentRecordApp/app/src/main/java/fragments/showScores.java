package fragments;

import android.app.Fragment;
import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.cmu.studentrecordapp.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import model.studentRecord;
import util.DatabaseConnector;

/**
 * Created by Peng on 4/6/15.
 */
public class showScores extends Fragment{

    private List<String> stuList = null;


    private class StableArrayAdapter extends ArrayAdapter<String> {

        HashMap<String, Integer> mIdMap = new HashMap<String, Integer>();

        public StableArrayAdapter(Context context, int textViewResourceId,
                                  List<String> objects) {
            super(context, textViewResourceId, objects);
            for (int i = 0; i < objects.size(); ++i) {
                mIdMap.put(objects.get(i), i);
            }
        }

        @Override
        public long getItemId(int position) {
            String item = getItem(position);
            return mIdMap.get(item);
        }

        @Override
        public boolean hasStableIds() {
            return true;
        }

    }


    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View view =  inflater.inflate(
                R.layout.showscores_fragment, container, false);
        final ListView listview = (ListView) view.findViewById(R.id.listview);
        DatabaseConnector dbConnector = new DatabaseConnector(this.getActivity());
        Cursor cursor = dbConnector.getAllRecords();

        putRecordsInList(cursor);
        StableArrayAdapter adapter = new StableArrayAdapter(this.getActivity(),
                android.R.layout.simple_list_item_1, stuList);
        listview.setAdapter(adapter);


        return view;
    }

    public void putRecordsInList(Cursor cursor) {
        StringBuilder s = new StringBuilder();
        s.append("Id"+"      ").append("q1"+"      ").append("q2"+"      ").append("q3"+"      ").append("q4"+"      ").append("q5"+"      ");
        stuList = new ArrayList<String>();
        stuList.add(s.toString());
        if (cursor != null) {
            while (cursor.moveToNext()) {
                s = new StringBuilder();
                studentRecord stu = new studentRecord(cursor.getInt(0),
                        cursor.getInt(1),
                        cursor.getInt(2),
                        cursor.getInt(3),
                        cursor.getInt(4),
                        cursor.getInt(5));
                s.append(stu.getStudentId()).append("      ").append(stu.getQ1() + "      ").
                        append(stu.getQ2() + "      ").
                        append(stu.getQ3() + "      ").
                        append(stu.getQ4() + "      ").
                        append(stu.getQ5() + "      ");
                stuList.add(s.toString());
            }

        }
    }

}





