package fragments;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.cmu.studentrecordapp.R;

import util.DatabaseConnector;

/*
 * Created by Peng on 4/6/15.
 */
public class showCalculations extends Fragment {

    private TextView q1H;
    private TextView q2H;
    private TextView q3H;
    private TextView q4H;
    private TextView q5H;

    private TextView q1L;
    private TextView q2L;
    private TextView q3L;
    private TextView q4L;
    private TextView q5L;


    private TextView q1A;
    private TextView q2A;
    private TextView q3A;
    private TextView q4A;
    private TextView q5A;
    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View view =  inflater.inflate(R.layout.showcalculations_fragment, container, false);
        q1H = (TextView) view.findViewById(R.id.q1HighText);
        q2H = (TextView) view.findViewById(R.id.q2HighText);
        q3H = (TextView) view.findViewById(R.id.q3HighText);
        q4H = (TextView) view.findViewById(R.id.q4HighText);
        q5H = (TextView) view.findViewById(R.id.q5HighText);

        q1L = (TextView) view.findViewById(R.id.q1LowText);
        q2L = (TextView) view.findViewById(R.id.q2LowText);
        q3L = (TextView) view.findViewById(R.id.q3LowText);
        q4L = (TextView) view.findViewById(R.id.q4LowText);
        q5L = (TextView) view.findViewById(R.id.q5LowText);

        q1A = (TextView) view.findViewById(R.id.q1AvgText);
        q2A = (TextView) view.findViewById(R.id.q2AvgText);
        q3A = (TextView) view.findViewById(R.id.q3AvgText);
        q4A = (TextView) view.findViewById(R.id.q4AvgText);
        q5A = (TextView) view.findViewById(R.id.q5AvgText);

        DatabaseConnector dbConnector = new DatabaseConnector(getActivity().getApplicationContext());

        q1H.setText(String.valueOf(dbConnector.getHighScore(1)));
        q2H.setText(String.valueOf(dbConnector.getHighScore(2)));
        q3H.setText(String.valueOf(dbConnector.getHighScore(3)));
        q4H.setText(String.valueOf(dbConnector.getHighScore(4)));
        q5H.setText(String.valueOf(dbConnector.getHighScore(5)));

        q1L.setText(String.valueOf(dbConnector.getLowScore(1)));
        q2L.setText(String.valueOf(dbConnector.getLowScore(2)));
        q3L.setText(String.valueOf(dbConnector.getLowScore(3)));
        q4L.setText(String.valueOf(dbConnector.getLowScore(4)));
        q5L.setText(String.valueOf(dbConnector.getLowScore(5)));

        q1A.setText(String.valueOf(dbConnector.getAvgScore(1)));
        q2A.setText(String.valueOf(dbConnector.getAvgScore(2)));
        q3A.setText(String.valueOf(dbConnector.getAvgScore(3)));
        q4A.setText(String.valueOf(dbConnector.getAvgScore(4)));
        q5A.setText(String.valueOf(dbConnector.getAvgScore(5)));



        return view;
    }
}
