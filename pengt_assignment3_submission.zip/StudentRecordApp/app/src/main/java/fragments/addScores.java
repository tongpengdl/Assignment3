package fragments;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.cmu.studentrecordapp.R;

import model.studentRecord;
import util.DatabaseConnector;


/**
 * Created by Peng on 4/6/15.
 */
public class addScores extends Fragment {

    private Button saveButton;

    private EditText studentEdit;
    private EditText q1Edit;
    private EditText q2Edit;
    private EditText q3Edit;
    private EditText q4Edit;
    private EditText q5Edit;

    private studentRecord stu;

    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View view =  inflater.inflate(R.layout.addscores_fragment, container, false);

        studentEdit = (EditText) view.findViewById(R.id.studentEdit);
        q1Edit = (EditText) view.findViewById(R.id.q1Edit);
        q2Edit = (EditText) view.findViewById(R.id.q2Edit);
        q3Edit = (EditText) view.findViewById(R.id.q3Edit);
        q4Edit = (EditText) view.findViewById(R.id.q4Edit);
        q5Edit = (EditText) view.findViewById(R.id.q5Edit);
        saveButton = (Button) view.findViewById(R.id.saveRecordButton);
        saveButton.setOnClickListener(new OnClickListener(){
            @Override
            public void onClick(View arg0) {
                 stu = new studentRecord(Integer.parseInt(studentEdit.getText().toString()),
                                            Integer.parseInt(q1Edit.getText().toString()),
                                            Integer.parseInt(q2Edit.getText().toString()),
                                            Integer.parseInt(q3Edit.getText().toString()),
                                            Integer.parseInt(q4Edit.getText().toString()),
                                            Integer.parseInt(q5Edit.getText().toString()));
                 saveRecords();

            }

        });

        return view;
    }

    protected void saveRecords(){
        DatabaseConnector databaseConnector = new DatabaseConnector(this.getActivity());
        if (this.getActivity().getIntent().getExtras() == null){
            databaseConnector.insertRecord(stu.getStudentId(),stu.getQ1(),stu.getQ2(),stu.getQ3(),stu.getQ4(),stu.getQ5());
        }else{
            databaseConnector.updateContact(stu.getStudentId(),stu.getQ1(),stu.getQ2(),stu.getQ3(),stu.getQ4(),stu.getQ5());
        }
    }



}
